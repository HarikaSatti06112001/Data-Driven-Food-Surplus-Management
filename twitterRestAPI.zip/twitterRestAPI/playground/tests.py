from django.test import TestCase

## Author: Ravi Teja Reddy
## This file contains the views for the Twitter API application.


# Create your tests here.
